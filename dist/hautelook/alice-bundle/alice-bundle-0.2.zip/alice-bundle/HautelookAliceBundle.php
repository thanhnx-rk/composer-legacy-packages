<?php

namespace Hautelook\AliceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HautelookAliceBundle extends Bundle
{
}
