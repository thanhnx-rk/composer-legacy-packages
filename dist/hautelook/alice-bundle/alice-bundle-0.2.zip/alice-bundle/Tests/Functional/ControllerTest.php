<?php

namespace Hautelook\AliceBundle\Tests\Functional;

/**
 * @group functional
 */
class ControllerTest extends TestCase
{
    public function testServiceSetup()
    {
        $client = $this->createClient();
    }
}
