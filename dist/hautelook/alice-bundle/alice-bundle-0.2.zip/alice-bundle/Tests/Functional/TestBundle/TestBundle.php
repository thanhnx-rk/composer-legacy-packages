<?php

namespace Hautelook\AliceBundle\Tests\Functional\TestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TestBundle extends Bundle
{
}
