<?php

namespace TFox\MpdfPortBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TFoxMpdfPortBundle extends Bundle
{
}
